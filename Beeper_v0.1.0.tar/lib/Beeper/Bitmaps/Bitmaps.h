#pragma once

#include "Icons/dashboard.xbm"
#include "Icons/beep_on.xbm"
#include "Icons/beep_off.xbm"
#include "Icons/wifi.xbm"
#include "Icons/sleep.xbm"
#include "Icons/scan.xbm"

#include "Fn/select_rectangle.xbm"
#include "Fn/scroll_points.xbm"

#include "Fn/wifi_point.xbm"
#include "Fn/wifi_low.xbm"
#include "Fn/wifi_1.xbm"
#include "Fn/wifi_2.xbm"
#include "Fn/wifi_3.xbm"
#include "Fn/wifi_4.xbm"